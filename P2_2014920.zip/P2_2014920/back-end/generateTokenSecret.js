const fs = require('fs');
const crypto = require('crypto');

// Gera uma string aleatória de 64 caracteres
const tokenSecret = crypto.randomBytes(32).toString('hex');

// Define o valor gerado para TOKEN_SECRET no arquivo .env
fs.appendFileSync('.env', `\nTOKEN_SECRET=${tokenSecret}`);

console.log('TOKEN_SECRET gerado com sucesso:', tokenSecret);
