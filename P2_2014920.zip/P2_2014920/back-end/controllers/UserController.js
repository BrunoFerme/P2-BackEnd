// Função para obter informações do utilizador
exports.getUser = function(req, res) {
    // Raciocínio lógico para obter informações do utilizador
    res.json({ message: 'Obter informações do utilizador' });
  };
  
  // Função para atualizar informações do utilizador
  exports.updateUser = function(req, res) {
    // Raciocínio lógico para atualizar informações do utilizador
    res.json({ message: 'Atualizar informações do utilizador' });
  };
  