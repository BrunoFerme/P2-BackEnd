const { DataTypes } = require('sequelize');
const db = require('../initdatabase');

const Lifestyle = db.sequelize.define('Lifestyle', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  id_usuario: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'User',
      key: 'id'
    },
    onDelete: 'CASCADE',
    onUpdate: 'CASCADE'
  },
  habitos_transporte: {
    type: DataTypes.STRING
  },
  uso_energia: {
    type: DataTypes.STRING
  },
  escolhas_alimentares: {
    type: DataTypes.STRING
  }
});

module.exports = Lifestyle;
