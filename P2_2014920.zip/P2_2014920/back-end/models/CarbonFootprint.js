const { DataTypes } = require('sequelize');
const db = require('../initdatabase');

const CarbonFootprint = db.sequelize.define('CarbonFootprint', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  id_usuario: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'User',
      key: 'id'
    },
    onDelete: 'CASCADE',
    onUpdate: 'CASCADE'
  },
  valor: {
    type: DataTypes.FLOAT
  },
  data: {
    type: DataTypes.DATE
  }
});

module.exports = CarbonFootprint;
