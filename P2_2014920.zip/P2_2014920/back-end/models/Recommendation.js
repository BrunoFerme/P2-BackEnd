const { DataTypes } = require('sequelize');
const db = require('../initdatabase');

const Recommendation = db.sequelize.define('Recommendation', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  id_usuario: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'User',
      key: 'id'
    },
    onDelete: 'CASCADE',
    onUpdate: 'CASCADE'
  },
  texto: {
    type: DataTypes.STRING
  }
});

module.exports = Recommendation;
