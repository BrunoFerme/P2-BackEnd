const Sequelize = require('sequelize');
const sequelize = new Sequelize(process.env.DB_SCHEMA, process.env.DB_USER, process.env.DB_PASS, {
    dialect: 'mysql',
//    dialectOptions: {
//      ssl: {
//        require: false
//      }
//    },
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    pool: {
      max: 30,
      min: 0,
      acquire: 30000,
      idle: 10000
    }
  });
  module.exports.sequelize = sequelize;