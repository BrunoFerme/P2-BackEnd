// Implementação de todos os modelos, utilizando a lógica do Sequelize

const db = require('./initdatabase');
const sequelize = db.sequelize;
const UserModel = require('./models/User');
const LifestyleModel = require('./models/Lifestyle');
const CarbonFootprintModel = require('./models/CarbonFootprint');
const RecommendationModel = require('./models/Recommendation');

// Autenticar à base de dados


// Definir os modelos
const User = sequelize.define('User', UserModel.attributes);
const Lifestyle = sequelize.define('Lifestyle', LifestyleModel.attributes);
const CarbonFootprint = sequelize.define('CarbonFootprint', CarbonFootprintModel.attributes);
const Recommendation = sequelize.define('Recommendation', RecommendationModel.attributes);

// Definir as relações entre os modelos
User.hasOne(Lifestyle, { foreignKey: 'user_id' });
User.hasOne(CarbonFootprint, { foreignKey: 'user_id' });
User.hasMany(Recommendation, { foreignKey: 'user_id' });

// Autenticar à base de dados
sequelize.authenticate()
  .then(() => {
    console.log('Conexão com o banco de dados estabelecida com sucesso!');
  })
  .catch((error) => {
    console.error('Erro ao conectar-se ao banco de dados:', error);
  });

// Sincronizar os modelos com o banco de dados
sequelize.sync({ force: false })
  .then(() => {
    console.log('Tabelas criadas!');
  })
  .catch((error) => {
    console.error('Erro ao criar as tabelas:', error);
  });

// Exportar as instâncias do Sequelize e os modelos
module.exports = {
  sequelize,
  User,
  Lifestyle,
  CarbonFootprint,
  Recommendation
};
